import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'employee-content',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {

  
  employeeData = [{
   empId : "123",
   firstName:  "George",
   lastName : "Harry",
   salary : "10000" ,
   dob : "01/10/1980",
   email : "d@gmail.com"
   
},
 {
  empId : "454",
  firstName:  "Mary",
  lastName : "larry",
  salary : "8000" ,
  dob : "05/20/1980",
  email : "e@gmail.com"
 },
 {
  empId : "454545",
  firstName:  "Sara",
  lastName : "Lee",
  salary : "5000" ,
  dob : "06/1/1990",
  email : "f@gmail.com"
 },
 {
  empId : "65000",
  firstName:  "Mona",
  lastName : "Harry",
  salary : "15000" ,
  dob : "01/01/2000",
  email : "asdsdadd@gmail.com"
 }

  ]

  constructor() { }

  ngOnInit(): void {
  }

}
